#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Мониторинг публичных TG-каналов-референсов через t.me/s/<канал>.

Каналы берутся из watchlist.json. Посты сохраняются в competitors/<канал>/
вместе с количеством просмотров — чтобы видеть, что заходит у других.

Запуск: python3 watch_channels.py            # последние ~40 постов каждого канала
        python3 watch_channels.py --pages 5  # глубже (по ~20 постов на страницу)
"""
import html
import json
import os
import re
import subprocess
import sys
import time

BASE = os.path.dirname(os.path.abspath(__file__))
WATCHLIST = os.path.join(BASE, "watchlist.json")
OUT_DIR = os.path.join(BASE, "competitors")

pages = 2
if "--pages" in sys.argv:
    pages = int(sys.argv[sys.argv.index("--pages") + 1])

try:
    channels = json.load(open(WATCHLIST, encoding="utf-8"))["channels"]
except FileNotFoundError:
    sys.exit("Нет watchlist.json. Добавь туда каналы: {\"channels\": [\"username1\", \"username2\"]}")

if not channels:
    sys.exit("Список каналов в watchlist.json пуст.")


def fetch(channel, before=None):
    url = f"https://t.me/s/{channel}"
    if before:
        url += f"?before={before}"
    r = subprocess.run(["curl", "-s", "--max-time", "60", url],
                       capture_output=True, text=True)
    return r.stdout if r.returncode == 0 else ""


def strip_html(fragment):
    fragment = re.sub(r"<br\s*/?>", "\n", fragment)
    fragment = re.sub(r"<[^>]+>", "", fragment)
    return html.unescape(fragment).strip()


for channel in channels:
    ch_dir = os.path.join(OUT_DIR, channel)
    os.makedirs(ch_dir, exist_ok=True)
    saved = 0
    before = None
    for _ in range(pages):
        page = fetch(channel, before)
        blocks = re.split(r'<div class="tgme_widget_message_wrap', page)[1:]
        ids = []
        for block in blocks:
            m_id = re.search(r'data-post="%s/(\d+)"' % channel, block)
            if not m_id:
                continue
            msg_id = int(m_id.group(1))
            ids.append(msg_id)
            m_date = re.findall(r'<time[^>]*datetime="([^"]+)"', block)
            date_iso = m_date[-1] if m_date else ""
            m_views = re.search(r'tgme_widget_message_views[^>]*>([^<]+)<', block)
            views = m_views.group(1).strip() if m_views else ""
            m_text = re.search(
                r'<div class="tgme_widget_message_text[^"]*"[^>]*>(.*?)</div>',
                block, re.DOTALL)
            text = strip_html(m_text.group(1)) if m_text else ""
            if not text:
                continue
            filename = f"{date_iso[:10]}_{msg_id:05d}.md"
            lines = [
                "---",
                f"id: {msg_id}",
                f"date: {date_iso[:10]} {date_iso[11:16]}",
                f"channel: {channel}",
                f"views: {views}",
                "---",
                "",
                text,
                "",
            ]
            with open(os.path.join(ch_dir, filename), "w", encoding="utf-8") as f:
                f.write("\n".join(lines))
            saved += 1
        if not ids:
            break
        before = min(ids)
        time.sleep(0.7)
    print(f"@{channel}: сохранено {saved} постов")
