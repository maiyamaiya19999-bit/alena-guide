#!/bin/bash
# Включает автосинхронизацию канала каждые 3 часа через launchd (штатный планировщик macOS).
# Запускать один раз: bash ~/tg-assistant/setup_autosync.sh
# Повторный запуск безопасен: старая задача выгружается и ставится заново.
set -e

LABEL="com.alena.tgsync"
PLIST="$HOME/Library/LaunchAgents/${LABEL}.plist"
SCRIPT="$HOME/tg-assistant/sync_all.sh"
LOG="/tmp/tgsync-alena.log"

if [ ! -f "$SCRIPT" ]; then
  echo "Не найден $SCRIPT"
  echo "Папка ассистента должна лежать в ~/tg-assistant (домашняя папка, не Рабочий стол)."
  exit 1
fi

mkdir -p "$HOME/Library/LaunchAgents"
chmod +x "$SCRIPT"

cat > "$PLIST" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key><string>${LABEL}</string>
  <key>ProgramArguments</key>
  <array>
    <string>/bin/bash</string>
    <string>${SCRIPT}</string>
  </array>
  <key>StartInterval</key><integer>10800</integer>
  <key>RunAtLoad</key><true/>
  <key>StandardOutPath</key><string>${LOG}</string>
  <key>StandardErrorPath</key><string>${LOG}</string>
</dict>
</plist>
PLIST

# Идемпотентно: сначала выгружаем старую версию задачи (если была), потом ставим новую.
launchctl unload "$PLIST" 2>/dev/null || true
launchctl load "$PLIST"

echo "Автосинхронизация включена: каждые 3 часа + при входе в систему."
echo "Задача: ${LABEL}"
echo "Лог:    ${LOG}"
echo "Проверить, что задача стоит: launchctl list | grep ${LABEL}"
