#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Разовый импорт истории канала из экспорта Telegram Desktop.

Как получить экспорт:
  Telegram Desktop → открыть канал → ⋮ → «Экспорт истории чата»
  → снять галочки с медиа (не обязательны) → формат JSON → экспортировать.

Запуск: python3 import_history.py /путь/к/result.json
Только посты с даты: python3 import_history.py /путь/к/result.json --since 2026-01-16
"""
import json
import os
import sys

BASE = os.path.dirname(os.path.abspath(__file__))
POSTS_DIR = os.path.join(BASE, "posts")

if len(sys.argv) < 2:
    sys.exit("Укажи путь к result.json: python3 import_history.py /путь/к/result.json [--since ГГГГ-ММ-ДД]")

since = ""
if "--since" in sys.argv:
    since = sys.argv[sys.argv.index("--since") + 1]

with open(sys.argv[1], encoding="utf-8") as f:
    data = json.load(f)

os.makedirs(POSTS_DIR, exist_ok=True)
channel = data.get("name", "")


def flatten_text(text):
    if isinstance(text, str):
        return text
    parts = []
    for chunk in text:
        if isinstance(chunk, str):
            parts.append(chunk)
        elif isinstance(chunk, dict):
            parts.append(chunk.get("text", ""))
    return "".join(parts)


MEDIA_KINDS = [
    ("photo", "фото"),
    ("media_type", None),  # video_message, voice_message, video_file, sticker...
]

count = 0
for msg in data.get("messages", []):
    if msg.get("type") != "message":
        continue
    text = flatten_text(msg.get("text", ""))
    media = []
    if "photo" in msg:
        media.append("фото")
    mt = msg.get("media_type")
    if mt:
        media.append({
            "video_file": "видео",
            "video_message": "кружок",
            "voice_message": "голосовое",
            "animation": "гифка",
            "sticker": "стикер",
            "audio_file": "аудио",
        }.get(mt, mt))
    if not text and not media:
        continue
    date = msg.get("date", "")  # "2024-01-01T12:00:00"
    day = date[:10]
    if since and day < since:
        continue
    hhmm = date[11:16]
    filename = f"{day}_{msg['id']:05d}.md"
    lines = [
        "---",
        f"id: {msg['id']}",
        f"date: {day} {hhmm}",
        f"channel: {channel}",
    ]
    if media:
        lines.append(f"media: {', '.join(media)}")
    lines += ["---", "", text, ""]
    with open(os.path.join(POSTS_DIR, filename), "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
    count += 1

print(f"Импортировано постов: {count}")
