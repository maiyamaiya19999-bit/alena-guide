#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Синхронизация постов из Telegram-канала в папку posts/.

Запуск: python3 sync_channel.py
Токен бота берётся из config.json (лежит рядом).
Забирает новые посты через getUpdates и сохраняет каждый в отдельный .md-файл.
"""
import datetime
import json
import os
import subprocess
import sys
import urllib.parse

BASE = os.path.dirname(os.path.abspath(__file__))
CONFIG_PATH = os.path.join(BASE, "config.json")
STATE_PATH = os.path.join(BASE, "state.json")
POSTS_DIR = os.path.join(BASE, "posts")


def load_json(path, default):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        return default


config = load_json(CONFIG_PATH, {})
token = config.get("bot_token", "")
if not token or "ВСТАВЬ" in token:
    sys.exit("Нет токена бота. Впиши его в config.json в поле bot_token.")

state = load_json(STATE_PATH, {"offset": 0})
os.makedirs(POSTS_DIR, exist_ok=True)

# Сначала забираем свежие изменения с GitHub (посты из облачных сессий с телефона)
if os.path.isdir(os.path.join(BASE, ".git")):
    subprocess.run(["git", "-C", BASE, "pull", "--rebase", "--quiet"],
                   capture_output=True, text=True)


def api(method, **params):
    url = f"https://api.telegram.org/bot{token}/{method}"
    data = urllib.parse.urlencode(params)
    result = subprocess.run(
        ["curl", "-s", "--max-time", "60", "-d", data, url],
        capture_output=True, text=True,
    )
    if result.returncode != 0 or not result.stdout:
        sys.exit(f"Сетевая ошибка ({method}): {result.stderr.strip()}")
    resp = json.loads(result.stdout)
    if not resp.get("ok"):
        sys.exit(f"Ошибка Telegram API ({method}): {resp}")
    return resp["result"]


MEDIA_KINDS = [
    ("photo", "фото"),
    ("video", "видео"),
    ("document", "файл"),
    ("voice", "голосовое"),
    ("video_note", "кружок"),
    ("audio", "аудио"),
    ("animation", "гифка"),
    ("poll", "опрос"),
    ("sticker", "стикер"),
]


def save_post(msg):
    text = msg.get("text") or msg.get("caption") or ""
    media = ", ".join(ru for key, ru in MEDIA_KINDS if key in msg)
    if not text and not media:
        return None
    date = datetime.datetime.fromtimestamp(msg["date"])
    channel = msg.get("chat", {}).get("title", "")
    filename = f"{date:%Y-%m-%d}_{msg['message_id']:05d}.md"
    lines = [
        "---",
        f"id: {msg['message_id']}",
        f"date: {date:%Y-%m-%d %H:%M}",
        f"channel: {channel}",
    ]
    if media:
        lines.append(f"media: {media}")
    lines += ["---", "", text, ""]
    with open(os.path.join(POSTS_DIR, filename), "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
    return filename


new_count = 0
edited_count = 0
while True:
    updates = api(
        "getUpdates",
        offset=state["offset"],
        timeout=0,
        allowed_updates='["channel_post","edited_channel_post"]',
    )
    if not updates:
        break
    for upd in updates:
        state["offset"] = upd["update_id"] + 1
        if "channel_post" in upd:
            if save_post(upd["channel_post"]):
                new_count += 1
        elif "edited_channel_post" in upd:
            if save_post(upd["edited_channel_post"]):
                edited_count += 1

with open(STATE_PATH, "w", encoding="utf-8") as f:
    json.dump(state, f)

total = len([n for n in os.listdir(POSTS_DIR) if n.endswith(".md")])
print(f"Новых постов: {new_count}, обновлённых: {edited_count}. Всего в архиве: {total}.")


def push_to_github():
    """Дублируем архив в приватный репозиторий, чтобы он был доступен с телефона."""
    if not os.path.isdir(os.path.join(BASE, ".git")):
        return
    def git(*args):
        return subprocess.run(["git", "-C", BASE, *args], capture_output=True, text=True)
    git("add", "-A")
    status = git("status", "--porcelain")
    if not status.stdout.strip():
        return
    git("commit", "-m", f"sync: +{new_count} новых, {edited_count} обновлённых")
    result = git("push")
    if result.returncode != 0:
        print(f"Не удалось отправить на GitHub: {result.stderr.strip()[:200]}")
    else:
        print("Архив отправлен на GitHub.")


if new_count or edited_count:
    push_to_github()
